#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVector>
#include <QKeyEvent>

struct Trip {
    qreal cost;
    QString name;
    QString date;
    QString toString() const
    {
        return QString::number(cost)+" "+name+" "+date;
    }
    bool operator<(const Trip& other) const
    {
        return cost < other.cost;
    }
    bool operator>(const Trip& other) const
    {
        return cost > other.cost;
    }
};

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
public:
    int getTripCount() const { return trips.size(); }
    Trip getTripAt(int index) const { return trips.value(index); }
    void sortTrips(bool ascending) {
        if (ascending) BinarySort();
        else StandartSort();
        UpdateTable();
        UpdateList();
    }
    bool validateInput(const QString& input) {
        bool ok;
        int value = input.toInt(&ok);
        return ok && value > 0;
    }
protected:
    void keyPressEvent(QKeyEvent *event) override;
    void contextMenuEvent(QContextMenuEvent *event) override;


public slots:
    void on_createButton_clicked();
    void on_exitButton_clicked();
    void on_addButton_clicked();
    void on_removeButton_clicked();
    void on_sortButton_clicked();

public:
    Ui::MainWindow *ui;
    QVector<Trip> trips;

    void UpdateTable();
    void UpdateList();
    void AddTripDialog();
    void AddTrip(const Trip& trip);
    void RemoveSelectedTrip();
    void BinarySort();
    void StandartSort();
};
#endif
