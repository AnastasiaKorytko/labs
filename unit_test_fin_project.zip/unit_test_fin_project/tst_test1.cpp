#include <QTest>
#include <QSignalSpy>
#include "C:\\Users\\Anastasia\\Desktop\\practice\\finalproject\\mainwindow.h"
#include "ui_mainwindow.h"

class TestMainWindow : public QObject
{
    Q_OBJECT

public:
    TestMainWindow();
    ~TestMainWindow();

private slots:
    void TestInput();
    void TestSinGraph();
    void TestCosGraph();
    void TestTgGraph();
    void TestCtgGraph();
    void TestClearGraphs();

private:
    MainWindow* m_mainWindow;
};

TestMainWindow::TestMainWindow()
{
    m_mainWindow = new MainWindow();
    m_mainWindow->show();
}

TestMainWindow::~TestMainWindow()
{
    delete m_mainWindow;
}

void TestMainWindow::TestInput()
{
    m_mainWindow->ui->xMinEdit->setText("-10");
    m_mainWindow->ui->xMaxEdit->setText("10");
    m_mainWindow->ui->yMinEdit->setText("-5");
    m_mainWindow->ui->yMaxEdit->setText("5");
    QVERIFY(m_mainWindow->Input());
    m_mainWindow->ui->xMinEdit->setText("abc");
    QVERIFY(!m_mainWindow->Input());
    m_mainWindow->ui->xMinEdit->setText("-10");
    m_mainWindow->ui->xMaxEdit->setText("-20");
    QVERIFY(!m_mainWindow->Input());
}

void TestMainWindow::TestSinGraph()
{
    m_mainWindow->ui->xMinEdit->setText("-10");
    m_mainWindow->ui->xMaxEdit->setText("10");
    m_mainWindow->ui->yMinEdit->setText("-2");
    m_mainWindow->ui->yMaxEdit->setText("2");
    m_mainWindow->on_SinButton_clicked();
    QVERIFY(m_mainWindow->Sin);
    QVERIFY(!m_mainWindow->sinPoints.isEmpty());
}

void TestMainWindow::TestCosGraph()
{
    m_mainWindow->ui->xMinEdit->setText("-10");
    m_mainWindow->ui->xMaxEdit->setText("10");
    m_mainWindow->ui->yMinEdit->setText("-2");
    m_mainWindow->ui->yMaxEdit->setText("2");
    m_mainWindow->on_CosButton_clicked();
    QVERIFY(m_mainWindow->Cos);
    QVERIFY(!m_mainWindow->cosPoints.isEmpty());
}

void TestMainWindow::TestTgGraph()
{
    m_mainWindow->ui->xMinEdit->setText("-3");
    m_mainWindow->ui->xMaxEdit->setText("3");
    m_mainWindow->ui->yMinEdit->setText("-10");
    m_mainWindow->ui->yMaxEdit->setText("10");
    m_mainWindow->on_TgButton_clicked();
    QVERIFY(m_mainWindow->Tg);
    QVERIFY(!m_mainWindow->tgSegm.isEmpty());
}

void TestMainWindow::TestCtgGraph()
{
    m_mainWindow->ui->xMinEdit->setText("-3");
    m_mainWindow->ui->xMaxEdit->setText("3");
    m_mainWindow->ui->yMinEdit->setText("-10");
    m_mainWindow->ui->yMaxEdit->setText("10");
    m_mainWindow->on_CtgButton_clicked();
    QVERIFY(m_mainWindow->Ctg);
    QVERIFY(!m_mainWindow->ctgSegm.isEmpty());
}

void TestMainWindow::TestClearGraphs()
{
    m_mainWindow->on_SinButton_clicked();
    m_mainWindow->on_CosButton_clicked();
    m_mainWindow->on_clearButton_clicked();
    QVERIFY(!m_mainWindow->Sin);
    QVERIFY(!m_mainWindow->Cos);
    QVERIFY(m_mainWindow->sinPoints.isEmpty());
    QVERIFY(m_mainWindow->cosPoints.isEmpty());
}



QTEST_MAIN(TestMainWindow)
#include "tst_test1.moc"
