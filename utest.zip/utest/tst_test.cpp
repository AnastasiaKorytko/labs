#include <QTest>
#include <QSignalSpy>
#include "C:\Users\Anastasia\Desktop\practice\lab1practice\mainwindow.h"
#include "ui_mainwindow.h"

class TestMainWindow : public QObject
{
    Q_OBJECT

public:
    TestMainWindow();
    ~TestMainWindow();

private slots:
    void TestCreateTrips();
    void TestAddTrip();
    void TestRemoveTrip();
    void TestSortTrips();
    void TestInputValidation();

private:
    MainWindow* m_mainWindow;
};

TestMainWindow::TestMainWindow()
{
    m_mainWindow = new MainWindow();
}

TestMainWindow::~TestMainWindow()
{
    delete m_mainWindow;
}

void TestMainWindow::TestCreateTrips()
{
    m_mainWindow->ui->lineEdit->setText("3");
    m_mainWindow->on_createButton_clicked();
    QCOMPARE(m_mainWindow->trips.size(), 3);
    QCOMPARE(m_mainWindow->ui->tableWidget->rowCount(), 3);
    QCOMPARE(m_mainWindow->ui->listWidget->count(), 3);
}

void TestMainWindow::TestAddTrip()
{
    int initialCount = m_mainWindow->trips.size();

    Trip testTrip = {1000.0, "Test Trip", "01.01.2023"};
    m_mainWindow->AddTrip(testTrip);

    QCOMPARE(m_mainWindow->trips.size(), initialCount + 1);
    QCOMPARE(m_mainWindow->trips.last().name, QString("Test Trip"));
}

void TestMainWindow::TestRemoveTrip()
{
    if (m_mainWindow->trips.isEmpty()) {
        Trip testTrip = {1000.0, "Test Trip", "01.01.2023"};
        m_mainWindow->AddTrip(testTrip);
    }

    int initialCount = m_mainWindow->trips.size();
    m_mainWindow->RemoveSelectedTrip();

    QCOMPARE(m_mainWindow->trips.size(), initialCount - 1);
}

void TestMainWindow::TestSortTrips()
{
    m_mainWindow->trips.clear();
    m_mainWindow->AddTrip({3000.0, "C", "01.01.2023"});
    m_mainWindow->AddTrip({1000.0, "A", "02.01.2023"});
    m_mainWindow->AddTrip({2000.0, "B", "03.01.2023"});

    m_mainWindow->BinarySort();
    QCOMPARE(m_mainWindow->trips[0].cost, 1000.0);

    m_mainWindow->StandartSort();
    QCOMPARE(m_mainWindow->trips[0].cost, 3000.0);
}

void TestMainWindow::TestInputValidation()
{
    QVERIFY(m_mainWindow->validateInput("5"));
    QVERIFY(!m_mainWindow->validateInput("-5"));
    QVERIFY(!m_mainWindow->validateInput("abc"));
}

QTEST_MAIN(TestMainWindow)
#include "tst_test.moc"
