#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <cmath>
#include <QMessageBox>
#include <QPainterPath>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->xMinEdit->setText(QString::number(xMin));
    ui->xMaxEdit->setText(QString::number(xMax));
    ui->yMinEdit->setText(QString::number(yMin));
    ui->yMaxEdit->setText(QString::number(yMax));
    setCursor(Qt::ArrowCursor);
}

MainWindow::~MainWindow()
{
    delete ui;
}

bool MainWindow::Input()
{
    bool a;
    xMin = ui->xMinEdit->text().toDouble(&a);
    if (!a) {
        QMessageBox::warning(this, "Ошибка", "Некорректное значение xMin");
        return false;
    }

    xMax = ui->xMaxEdit->text().toDouble(&a);
    if (!a || xMax <= xMin) {
        QMessageBox::warning(this, "Ошибка", "Некорректное значение xMax");
        return false;
    }

    yMin = ui->yMinEdit->text().toDouble(&a);
    if (!a) {
        QMessageBox::warning(this, "Ошибка", "Некорректное значение yMin");
        return false;
    }

    yMax = ui->yMaxEdit->text().toDouble(&a);
    if (!a || yMax <= yMin) {
        QMessageBox::warning(this, "Ошибка", "Некорректное значение yMax");
        return false;
    }

    return true;
}

void MainWindow::on_SinButton_clicked()
{
    if (!Input())
        return;
    Sin = true;
    Points();
    update();
}

void MainWindow::on_CosButton_clicked()
{
    if (!Input())
        return;
    Cos = true;
    Points();
    update();
}

void MainWindow::on_TgButton_clicked()
{
    if (!Input())
        return;
    Tg = true;
    Points();
    update();
}

void MainWindow::on_CtgButton_clicked()
{
    if (!Input())
        return;
    Ctg = true;
    Points();
    update();
}

void MainWindow::on_clearButton_clicked()
{
    Sin = false;
    Cos = false;
    Tg = false;
    Ctg = false;
    sinPoints.clear();
    cosPoints.clear();
    tgSegm.clear();
    ctgSegm.clear();
    update();
}

void MainWindow::Points()
{
    sinPoints.clear();
    cosPoints.clear();
    tgSegm.clear();
    ctgSegm.clear();
    const int Max = 1000;
    const double step = (xMax - xMin) / Max;

    QVector<double> values(Max);
    for (int i = 0; i < Max; i++) {
        values[i] = xMin + i * step;
    }

    if (Sin) {
        sinPoints.reserve(Max);
        for (double x : values) {
            sinPoints.append(QPointF(x, sin(x)));
        }
    }

    if (Cos) {
        cosPoints.reserve(Max);
        for (double x : values) {
            cosPoints.append(QPointF(x, cos(x)));
        }
    }

    if (Tg) {
        QVector<QPointF> segment;
        segment.reserve(Max);
        for (double x : values) {
            double cos_x = cos(x);
            if (fabs(cos_x) > 1e-3) {
                double yTg = tan(x);
                if (yTg >= yMin && yTg <= yMax) {
                    segment.append(QPointF(x, yTg));
                } else if (!segment.isEmpty()) {
                    tgSegm.append(segment);
                    segment.clear();
                }
            } else if (!segment.isEmpty()) {
                tgSegm.append(segment);
                segment.clear();
            }
        }
        if (!segment.isEmpty()) {
            tgSegm.append(segment);
        }
    }

    if (Ctg) {
        QVector<QPointF> segment;
        segment.reserve(Max);
        for (double x : values) {
            double sin_x = sin(x);
            if (fabs(sin_x) > 1e-3) {
                double yCtg = cos(x)/sin_x;
                if (yCtg >= yMin && yCtg <= yMax) {
                    segment.append(QPointF(x, yCtg));
                } else if (!segment.isEmpty()) {
                    ctgSegm.append(segment);
                    segment.clear();
                }
            } else if (!segment.isEmpty()) {
                ctgSegm.append(segment);
                segment.clear();
            }
        }
        if (!segment.isEmpty()) {
            ctgSegm.append(segment);
        }
    }
}


void MainWindow::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);
    QRect rect = QRect(ui->Rect->pos(), ui->Rect->size());
    rect.adjust(10, 10, -10, -15);
    QPixmap img("C:\\Users\\Anastasia\\Desktop\\practice\\img.jpg");
    painter.drawPixmap(rect, img);
    CoordSystem(painter, rect);
    painter.setFont(QFont("Times New Roman",15));

    if (Sin)
    {
        painter.setPen(Qt::blue);
        Graph(painter, rect, sinPoints);
    }
    if (Cos)
    {
        painter.setPen(Qt::red);
        Graph(painter, rect, cosPoints);
    }
    if (Tg)
    {
        AsymptotesTg(painter, rect);
        painter.setPen(Qt::green);
        GraphTgCtg(painter, rect, tgSegm);
    }
    if (Ctg)
    {
        AsymptotesCtg(painter, rect);
        painter.setPen(Qt::darkYellow);
        GraphTgCtg(painter, rect, ctgSegm);
    }

    if (Sin) {
        painter.setPen(Qt::blue);
        painter.drawText(rect.right() - 100, rect.top() + 20, "sin(x)");
    }
    if (Cos) {
        painter.setPen(Qt::red);
        painter.drawText(rect.right() - 100, rect.top() + 40, "cos(x)");
    }
    if (Tg) {
        painter.setPen(Qt::green);
        painter.drawText(rect.right() - 100, rect.top() + 60, "tg(x)");
    }
    if (Ctg) {
        painter.setPen(Qt::darkYellow);
        painter.drawText(rect.right() - 100, rect.top() + 80, "ctg(x)");
    }
}

QPointF MainWindow::Display(const QPointF &point, const QRect &rect)
{
    double normX = (point.x() - xMin) / (xMax - xMin);
    double normY = (point.y() - yMin) / (yMax - yMin);
    return QPointF(rect.left() + normX * rect.width(), rect.bottom() - normY * rect.height());
}


void MainWindow::CoordSystem(QPainter &painter, const QRect &rect)
{
    painter.setPen(Qt::black);
    painter.drawRect(rect);
    QPointF zero = Display(QPointF(0, 0), rect);

    if (xMin <= 0 && xMax >= 0) {
        painter.drawLine(QPointF(zero.x(), rect.top()), QPointF(zero.x(), rect.bottom()));
    }
    if (yMin <= 0 && yMax >= 0) {
        painter.drawLine(QPointF(rect.left(), zero.y()), QPointF(rect.right(), zero.y()));
    }

    painter.drawText(rect.right() - 15, zero.y() - 5, "X");
    painter.drawText(zero.x() + 5, rect.top() + 15, "Y");
    painter.setFont(QFont("Times New Roman", 8));

    double xstep = (xMax - xMin) / 10;
    for (double x = xMin; x <= xMax; x += xstep) {
        QPointF point = Display(QPointF(x, 0), rect);
        painter.drawLine(point.x(), rect.bottom() - 5, point.x(), rect.bottom() + 5);
        painter.drawText(point.x() - 5, rect.bottom() + 20, QString::number(x));
    }
    double ystep = (yMax - yMin) / 10;
    for (double y = yMin; y <= yMax; y += ystep) {
        QPointF point = Display(QPointF(0, y), rect);
        painter.drawLine(rect.left() - 5, point.y(), rect.left() + 5, point.y());
        painter.drawText(rect.left() - 15, point.y() + 5, QString::number(y));
    }
}

void MainWindow::Graph(QPainter &painter, const QRect &rect, const QVector<QPointF> &points)
{
    if (points.isEmpty())
        return;

    QPainterPath path;
    path.moveTo(Display(points.first(), rect));
    for (int i = 1; i < points.size(); i++) {
        path.lineTo(Display(points[i], rect));
    }
    painter.drawPath(path);
}

void MainWindow::GraphTgCtg(QPainter &painter, const QRect &rect, const QVector<QVector<QPointF>> &segments)
{
    if (segments.isEmpty())
        return;
    else
    {
    for (const QVector<QPointF> &segment : segments) {
        if (segment.size() < 2)
            continue;

        QPainterPath path;
        path.moveTo(Display(segment.first(), rect));
        for (int i = 1; i < segment.size(); i++) {
            path.lineTo(Display(segment[i], rect));
        }
        painter.drawPath(path);
    }
    }
}

void MainWindow::AsymptotesTg(QPainter &painter, const QRect &rect)
{
    QPen pen;
    pen.setColor(Qt::gray);
    pen.setStyle(Qt::DashLine);
    painter.setPen(pen);
    if (Tg) {
        double pi = M_PI;
        double startX = ceil((xMin - pi/2) / pi) * pi + pi/2;

        for (double x = startX; x <= xMax; x += pi) {
            if (x >= xMin) {
                QPointF p = Display(QPointF(x, 0), rect);
                painter.drawLine(p.x(), rect.top(), p.x(), rect.bottom());
            }
        }
    }
}

void MainWindow::AsymptotesCtg(QPainter &painter, const QRect &rect)
{
    QPen pen;
    pen.setColor(Qt::gray);
    pen.setStyle(Qt::DashLine);
    painter.setPen(pen);
    if (Ctg) {
        double pi = M_PI;
        double startX = ceil(xMin / pi) * pi;

        for (double x = startX; x <= xMax; x += pi) {
            if (x >= xMin) {
                QPointF p = Display(QPointF(x, 0), rect);
                painter.drawLine(p.x(), rect.top(), p.x(), rect.bottom());
            }
        }
    }
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    if (Qt::Key_Escape){
        QApplication::quit();
    }
    QMainWindow::keyPressEvent(event);
}

void MainWindow::wheelEvent(QWheelEvent *event)
{
    QPoint MousePos = event->position().toPoint();
    QRect Rect = QRect(ui->Rect->pos(), ui->Rect->size());
    if (!Rect.contains(MousePos)) {
        event->ignore();
        return;
    }
    int angle = event->angleDelta().y();
    double zoom;
    if (angle > 0) {
        zoom = 1.0 / (1.0 + step);
    } else {
        zoom = 1.0 + step;
    }
    double prevx = xMax - xMin;
    double prevy = yMax - yMin;
    double newx = prevx * zoom;
    double newy = prevy * zoom;
    double xc = xMin + prevx * (MousePos.x() - Rect.left()) / Rect.width();
    double yc = yMin + prevy * (Rect.bottom() - MousePos.y()) / Rect.height();
    xMin = xc - newx / 2;
    xMax = xc + newx / 2;
    yMin = yc - newy / 2;
    yMax = yc + newy / 2;
    ui->xMinEdit->setText(QString::number(xMin));
    ui->xMaxEdit->setText(QString::number(xMax));
    ui->yMinEdit->setText(QString::number(yMin));
    ui->yMaxEdit->setText(QString::number(yMax));
    Points();
    update();
    event->accept();
}
void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    if (is) {
        QPointF a = event->pos() - LastPos;
        LastPos = event->pos();
        double dx = (xMax - xMin) * a.x() / ui->Rect->width();
        double dy = (yMax - yMin) * a.y() / ui->Rect->height();
        xMin -= dx;
        xMax -= dx;
        yMin += dy;
        yMax += dy;
        ui->xMinEdit->setText(QString::number(xMin));
        ui->xMaxEdit->setText(QString::number(xMax));
        ui->yMinEdit->setText(QString::number(yMin));
        ui->yMaxEdit->setText(QString::number(yMax));
        Points();
        update();
    }
    QMainWindow::mouseMoveEvent(event);
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        QRect Rect = ui->Rect->geometry();
        if (Rect.contains(event->pos())) {
            is = true;
            LastPos = event->pos();
            setCursor(Qt::ClosedHandCursor);
        }
    }
    QMainWindow::mousePressEvent(event);
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton && is) {
        is = false;
        setCursor(Qt::ArrowCursor);
    }
    QMainWindow::mouseReleaseEvent(event);
}






