#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPainter>
#include <QVector>
#include <QKeyEvent>
#include <QWheelEvent>
#include <QMouseEvent>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

public:
    void paintEvent(QPaintEvent *event) override;
    void keyPressEvent(QKeyEvent *event) override;
    void wheelEvent(QWheelEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;

public slots:
    void on_SinButton_clicked();
    void on_CosButton_clicked();
    void on_TgButton_clicked();
    void on_CtgButton_clicked();
    void on_clearButton_clicked();

public:
    Ui::MainWindow *ui;

    double xMin = -10, xMax = 10;
    double yMin = -5, yMax = 5;
    bool Sin = false;
    bool Cos = false;
    bool Tg = false;
    bool Ctg = false;

    QVector<QPointF> sinPoints;
    QVector<QPointF> cosPoints;
    QVector<QVector<QPointF>> tgSegm;
    QVector<QVector<QPointF>> ctgSegm;

    bool Input();
    void Points();
    QPointF Display(const QPointF &point, const QRect &rect);
    void CoordSystem(QPainter &painter, const QRect &rect);
    void Graph(QPainter &painter, const QRect &rect, const QVector<QPointF> &points);
    void GraphTgCtg(QPainter &painter, const QRect &rect, const QVector<QVector<QPointF>> &segments);
    void AsymptotesTg(QPainter &painter, const QRect &rect);
    void AsymptotesCtg(QPainter &painter, const QRect &rect);

    double zoom = 1.0;
    const double step = 0.01;
    QPointF GraphCenter;
    QPointF LastPos;
    bool is = false;
};
#endif // MAINWINDOW_H
