#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QInputDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->tableWidget->setColumnCount(3);
    ui->tableWidget->setHorizontalHeaderLabels({"Стоимость", "Город", "Дата"});
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);

    ui->sortOrderComboBox->addItem("По возрастанию");
    ui->sortOrderComboBox->addItem("По убыванию");

    ui->listWidget->setSelectionMode(QAbstractItemView::SingleSelection);

    ui->label->setPixmap(QPixmap("C:\\Users\\Anastasia\\Desktop\\practice\\images.jfif"));

    connect(ui->createButton, &QPushButton::clicked, this, &MainWindow::on_createButton_clicked);
    connect(ui->addButton, &QPushButton::clicked, this, &MainWindow::on_addButton_clicked);
    // connect(ui->removeButton, &QPushButton::clicked, this, &MainWindow::on_removeButton_clicked);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::UpdateTable()
{
    ui->tableWidget->clearContents();
    ui->tableWidget->setRowCount(trips.size());

    for (int i = 0; i < trips.size(); i++) {
        ui->tableWidget->setItem(i, 0, new QTableWidgetItem(QString::number(trips[i].cost)));
        ui->tableWidget->setItem(i, 1, new QTableWidgetItem(trips[i].name));
        ui->tableWidget->setItem(i, 2, new QTableWidgetItem(trips[i].date));
    }
}
void MainWindow::UpdateList()
{
    ui->listWidget->clear();
    for (int i = 0; i < trips.size(); i++) {
        ui->listWidget->addItem(trips[i].toString());
    }
}

void MainWindow::on_createButton_clicked()
{
    int size = ui->lineEdit->text().toInt();

    if (size <= 0) {
        QMessageBox::warning(this, "Ошибка", "Некорректнфй ввод");
        return;
    }

    trips.clear();

    QVector<Trip> Tr = {
        {1500.0, "Париж", "15.05.2023"},
        {3500.0, "Нью-Йорк", "20.06.2023"},
        {800.0, "Прага", "10.04.2023"},
        {6000.0, "Токио", "05.09.2023"},
        {7000.0, "Рим", "08.08.2023"}
    };

    for (int i = 0; i < size && i < Tr.size(); i++) {
        trips.append(Tr[i]);
    }

    UpdateTable();
    UpdateList();
}

void MainWindow::on_addButton_clicked()
{
    AddTripDialog();
}

void MainWindow::AddTripDialog()
{
    bool ok;
    qreal cost = QInputDialog::getDouble(this, "Добавить поездку",
                                         "Стоимость:", 0, 0, 100000, 2, &ok);
    if (!ok) return;

    QString name = QInputDialog::getText(this, "Добавить поездку",
                                         "Город:");
    if (name.isEmpty()) return;

    QString date = QInputDialog::getText(this, "Добавить поездку",
                                         "Дата (дд.мм.гггг):");

    AddTrip({cost, name, date});
}
void MainWindow::AddTrip(const Trip& trip)
{
    trips.append(trip);
    UpdateTable();
    UpdateList();
    ui->tableWidget->setCurrentCell(trips.size()-1, 0);
    ui->listWidget->setCurrentRow(trips.size()-1);
}

void MainWindow::on_removeButton_clicked()
{
    RemoveSelectedTrip();
}
void MainWindow::RemoveSelectedTrip()
{
    int rowToRemove = ui->tableWidget->currentRow();

    if (rowToRemove >= 0 && rowToRemove < trips.size()) {
        trips.remove(rowToRemove);
        UpdateTable();
        UpdateList();
    } else {
        QMessageBox::warning(this, "Ошибка", "Выберите поездку для удаления");
    }
}
void MainWindow::on_exitButton_clicked()
{
    QApplication::quit();
}
void MainWindow::keyPressEvent(QKeyEvent *event)
{
    switch(event->key()) {
    case Qt::Key_Escape:
        QApplication::quit();
        break;
    case Qt::Key_Plus:
        on_addButton_clicked();
    case Qt::Key_Minus:
        on_removeButton_clicked();
        break;
    default:
        QMainWindow::keyPressEvent(event);
}
}
void MainWindow::contextMenuEvent(QContextMenuEvent *event)
{
    QMenu menu(this);
    QAction *addAction = menu.addAction("Добавить поездку");
    QAction *removeAction = menu.addAction("Удалить поездку");
    menu.addSeparator();
    QAction *exitAction = menu.addAction("Выход");
    connect(addAction, &QAction::triggered, this, &MainWindow::on_addButton_clicked);
    connect(removeAction, &QAction::triggered, this, &MainWindow::on_removeButton_clicked);
    connect(exitAction, &QAction::triggered, this, &MainWindow::on_exitButton_clicked);
    menu.exec(event->globalPos());
}
void MainWindow::on_sortButton_clicked()
{
    bool a = ui->sortOrderComboBox->currentIndex() == 0;
    if (a)
    {
        BinarySort();
    }
    else
    {
        StandartSort();
    }
    UpdateTable();
    UpdateList();
}

void MainWindow::BinarySort()
{
    for (int i = 1; i < trips.size(); i++)
    {
        Trip key = trips[i];
        int left = 0;
        int right = i;
        while (left < right)
        {
            int mid = left + (right - left) / 2;
            if (trips[mid].cost < key.cost)
            {
                left = mid + 1;
            }
            else
            {
                right = mid;
            }
        }
        for (int j = i; j > left; j--)
        {
            trips[j] = trips[j - 1];
        }
        trips[left] = key;
    }
}
void MainWindow::StandartSort()
{
    std::sort(trips.begin(), trips.end(), [](Trip a, Trip b){ return a > b; });

}

